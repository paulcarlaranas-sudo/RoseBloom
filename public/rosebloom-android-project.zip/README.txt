ROSEBLOOM MONTHSARY - ANDROID APPLICATION
================================================

This package contains:
1. rosebloom-monthsary.apk: Standalone Android App installer package.
2. Android Studio Project: Complete source code ready to open in Android Studio.
3. WebAPK / PWA: Instant install directly via Google Chrome on Android.

How to Install on Android:
--------------------------
Option A: Direct APK Install
1. Transfer rosebloom-monthsary.apk to your Android phone (or download it directly from the website).
2. Tap the .apk file in your Files / Downloads app.
3. If prompted, allow "Install unknown apps" for your browser/file manager.
4. Tap "Install".

Option B: Instant 1-Click PWA / WebAPK (Recommended)
1. Open the Rosebloom website in Google Chrome on your Android device.
2. Tap "Android App" -> "Install to Android Home Screen Now" or tap Chrome's menu (3 dots) -> "Install app".
3. Android creates an official WebAPK with native launcher icon, fullscreen immersion, and offline caching.

Option C: Build in Android Studio
1. Open this folder in Android Studio.
2. Run 'Build' -> 'Build Bundle(s) / APK(s)' -> 'Build APK(s)'.
